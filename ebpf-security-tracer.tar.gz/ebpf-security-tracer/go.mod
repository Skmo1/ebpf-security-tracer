module github.com/TON_USER/ebpf-security-tracer

go 1.22

require github.com/cilium/ebpf v0.15.0
